class Score { }
class Food { }
class Foods { }